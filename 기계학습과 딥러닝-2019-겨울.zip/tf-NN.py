import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split
def minmaxscaler(data):
    numerator = data - np.min(data, 0)
    denominator = np.max(data, 0) - np.min(data, 0)
    return numerator / denominator

xy = np.loadtxt('white.csv', skiprows=1, delimiter=',', dtype=np.float32)
x_data = xy[:, 0:-1]; y_data = xy[:, [-1]]
ymax, ymin = np.max(y_data), np.min(y_data)
xy = minmaxscaler(xy)
x_data = xy[:, 0:-1]; y_data = xy[:, [-1]]
X_train, X_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.3, random_state=100)
y_test = y_test*(ymax-ymin)+ymin

def multilayer_perceptron(x, weights, biases, keep_prob):
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.relu(layer_1)
    layer_1 = tf.nn.dropout(layer_1, keep_prob)
    out_layer = tf.matmul(layer_1, weights['out']) + biases['out']
    return out_layer

## Build graph using tensorflow operations
n_hidden_1 = 36; n_input = X_train.shape[1]
keep_prob = tf.placeholder("float")
W = {
    'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1])),
    'out': tf.Variable(tf.random_normal([n_hidden_1, n_input]))
}
B = {
    'b1': tf.Variable(tf.random_normal([n_hidden_1])),
    'out': tf.Variable(tf.random_normal([1]))
}

X = tf.placeholder(tf.float32, shape=[None, n_input])
Y = tf.placeholder(tf.float32, shape=[None, 1])
# Linear regression
mu = multilayer_perceptron(X, W, B, keep_prob)
cost = tf.reduce_mean(tf.square(mu-Y))
optimizer = tf.train.AdamOptimizer(learning_rate=0.001)
train = optimizer.minimize(cost)   
sess = tf.Session()
sess.run(tf.global_variables_initializer())
for step in range(10001):
    cost_val, mu_val, _ = sess.run([cost, mu, train], feed_dict={X: X_train, Y: y_train, keep_prob: 0.8})
    if step % 1000 == 0:
        print(step, "Cost: ", cost_val, "\nPrediction:\n", mu_val)
# 예측 & MSE
muhat = sess.run(mu, feed_dict={X: X_test})
pred = muhat*(ymax-ymin)+ymin
print(sess.run(tf.reduce_mean(tf.square(pred-y_test))))

