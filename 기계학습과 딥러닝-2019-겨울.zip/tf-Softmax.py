import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data

mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)

digit_classes=10
n_pixel = 784
X = tf.placeholder(tf.float32,[None, n_pixel])
Y = tf.placeholder(tf.float32,[None, digit_classes])  
W = tf.Variable(tf.random_normal([n_pixel, digit_classes]))
b = tf.Variable(tf.random_normal([digit_classes]))
mu = tf.nn.softmax(tf.matmul(X,W)+b)
cost = tf.reduce_mean(-tf.reduce_sum(Y*tf.log(mu),axis=1))
optimizer = tf.train.AdamOptimizer(learning_rate=0.0001)
train = optimizer.minimize(cost)    
correct = tf.equal(tf.arg_max(mu,1), tf.arg_max(Y,1))
accuracy = tf.reduce_mean(tf.cast(correct, tf.float32))

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for step in range(5001):
        X_train, y_train = mnist.train.next_batch(500)
        cost_val, _ = sess.run([cost, train],feed_dict={X: X_train, Y: y_train})
        if step % 500 == 0:
            print(step, cost_val)
    print("\nAccuracy:", sess.run(accuracy, feed_dict={X: mnist.test.images, Y: mnist.test.labels}))
	