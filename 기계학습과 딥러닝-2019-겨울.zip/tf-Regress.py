import tensorflow as tf  
import numpy as np

xy = np.loadtxt('white.csv', skiprows=1, delimiter=',', dtype=np.float32)
x_data = xy[:, 0:-1];  y_data = xy[:, [-1]]; y_origin = y_data

## Build graph using tensorflow operations
X = tf.placeholder(tf.float32, shape=[None, 11])
Y = tf.placeholder(tf.float32, shape=[None, 1])
W = tf.Variable(tf.random_normal([11, 1]), name='weight')
b = tf.Variable(tf.random_normal([1]), name='bias')

# Linear regression
mu = tf.matmul(X, W)+b
cost = tf.reduce_mean(tf.square(mu-Y))
optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.01)
train = optimizer.minimize(cost)  

## feed data and run graph & update variables in the graph
sess = tf.Session()
sess.run(tf.global_variables_initializer())
for step in range(201):
    cost_val, mu_val, _ = sess.run(
        [cost, mu, train], feed_dict={X: x_data, Y: y_data})
    if step % 20 == 0:
        print(step, "Cost: ", cost_val, "\nPrediction:\n", mu_val)

def minmaxscaler(data):
    numerator = data - np.min(data, 0)
    denominator = np.max(data, 0) - np.min(data, 0)
    return numerator / denominator           
    # noise term prevents the zero division:  (denominator + 1e-7)

from sklearn.model_selection import train_test_split
ymax, ymin = np.max(y_data), np.min(y_data)
xy = minmaxscaler(xy)
x_data = xy[:, 0:-1]
y_data = xy[:, [-1]]
X_train, X_test, y_train, y_test = train_test_split(x_data,
   y_data, test_size=0.3, random_state=100)

y_test = y_test*(ymax-ymin)+ymin

sess = tf.Session()
sess.run(tf.global_variables_initializer())
for step in range(2001):
    cost_val, mu_val, _ = sess.run(
        [cost, mu, train], feed_dict={X: X_train, Y: y_train})
    if step % 100 == 0:
        print(step, "Cost: ", cost_val, "\nPrediction:\n", mu_val)

# 표준화된 데이터의 weights, bias 추정 
print("Weight\n",sess.run(W), "\nbias:",sess.run(b))  
# 예측 & MSE 
muhat = sess.run(mu, feed_dict={X: X_test})
pred = muhat*(ymax-ymin)+ymin
print(sess.run(tf.reduce_mean(tf.square(pred-y_test))))
