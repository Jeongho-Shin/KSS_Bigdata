import numpy as np
from sklearn import datasets   
# iris data
iris = datasets.load_iris()
X = iris.data[:, :4]; Y = iris.target

import statsmodels.api as sm
X = sm.add_constant(X, prepend = False)
mlogit_sm = sm.MNLogit(Y, X).fit(maxiter=100)
print (mlogit_sm.summary())   # Perfect separation
mlogit_sm = sm.MNLogit(Y, X).fit(method='bfgs',maxiter=100)
mlogit_sm.summary()
prob = mlogit_sm.predict(X)
print(prob)
yhat = np.argmax(prob,1)
print(yhat)

# LASSO with statmodels
from statsmodels.discrete.discrete_model import MNLogit
mlogit_sm = MNLogit(Y,X)
mlogit_smL = mlogit_sm.fit_regularized(method="l1", alpha=0.5)
yhatL = np.argmax(mlogit_smL.predict(X),1)
print(yhatL)

# sklearn
from sklearn.linear_model import LogisticRegression
mlogitR = LogisticRegression(C=1e5)  # multi_class={'ovr','multinomial'}  
X = iris.data[:, :4]
mlogitR.fit(X,Y)
muR = mlogitR.predict_proba(X)
print(muR)
yhatR = np.argmax(muR,1)
print(yhatR)

