# Logistic regression
import tensorflow as tf
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

xy = np.loadtxt('white.csv',skiprows=1, delimiter=',', dtype=np.float32)
y_origin = xy[:, [-1]]; y_binary = (y_origin > 5)
scaler = MinMaxScaler(); scaler.fit(xy); xy = scaler.transform(xy)
x_data = xy[:, 0:-1]
X_train, X_test, y_train, y_test = train_test_split(x_data, y_binary, test_size=0.3, random_state=100)

X = tf.placeholder(tf.float32, shape=[None, 11])
Y = tf.placeholder(tf.float32, shape=[None, 1])
W = tf.Variable(tf.random_normal([11, 1]), name='weight')
b = tf.Variable(tf.random_normal([1]), name='bias')

# logit link
mu = tf.sigmoid(tf.matmul(X, W) + b)    
# - log-likelihood function
cost = -tf.reduce_mean(Y*tf.log(mu)+(1-Y)*tf.log(1-mu)) 
optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.01)
train = optimizer.minimize(cost)    
predicted = tf.cast(mu > 0.5, dtype=tf.float32)
accuracy = tf.reduce_mean(tf.cast(tf.equal(predicted, Y), dtype=tf.float32))

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for step in range(10001):
        cost_val, _ = sess.run([cost, train],feed_dict={X: X_train, Y: y_train})
        if step % 1000 == 0:
            print(step, cost_val)
    h, c, a = sess.run([mu, predicted, accuracy], feed_dict={X: X_test, Y: y_test})
print("\nMu: ", h, "\nPredict(Y): ", c, "\nAccuracy: ", a)

