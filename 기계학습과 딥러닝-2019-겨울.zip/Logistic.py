import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 
import statsmodels.api as sm

white = pd.read_csv("white.csv")   # dataframe 형태
white = white[-np.isnan(white["y"])]
white["good"] = (white.y > 5).astype(float)
X = np.array(white.drop(["y","good"],1))
y_binary = np.array(white["good"])
X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.3, random_state=100)

## Logistic Regression()
# statmodels
logit_sm = sm.Logit(y_train, sm.add_constant(X_train)).fit()
print(logit_sm.summary())     
   # logit_sm.params, logit_sm.fittedvalues(=eta), 
   # logit_sm.model.cdf(eta)
muhat = logit_sm.predict(sm.add_constant(X_test))
(muhat > 0.5).astype(int)
# 모형(변수)지정
import statsmodels.formula.api as smf
model = "good ~ x1+x2+x4+x6+x10"
logit_smf = smf.logit(formula=str(model),data=white).fit()
logit_smf.summary()

#sklearn : “statsmodels” 결과와 다름
from sklearn.linear_model import LogisticRegression
logitR = LogisticRegression()    
logitR.fit(X_train, y_train, sample_weight=None)  
print(logitR.coef_, logitR.intercept_)       # Ridge
logitL = LogisticRegression(penalty="l1")  # LASSO , C = 1/alpha    
logitL.fit(X_train, y_train, sample_weight=None)   
muL = logitL.predict_proba(X_test)
print(muL)
yhat = logitL.predict(X_test) 
print(yhat)
logitL.score(X_test, y_test, sample_weight=None) 
