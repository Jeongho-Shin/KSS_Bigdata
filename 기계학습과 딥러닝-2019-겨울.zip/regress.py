import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split  
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.metrics import mean_squared_error
import statsmodels.api as sm

white = pd.read_csv("white.csv")   # dataframe 형태
whiteN = np.loadtxt('white.csv', skiprows=1, delimiter=',', dtype=np.float32)
   # array 형태
white.head()    # white.tail()
white = white[-np.isnan(white["y"])]
X = np.array(white.drop(["y"],1));  y = np.array(white["y"])
# train data & test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=100)

## Multiple linear regression

# statmodels packages
model = sm.OLS(y_train, sm.add_constant(X_train)) # sm.OLS(y,x)와 비교
results = model.fit()   # sm.OLS(y_train, sm.add_constant(X_train)).fit() 
print(results.summary())

# sklearn package
lrm = LinearRegression(n_jobs=-1)     # 입력값형식: array-like, matrix
  # fit_intercept = True, normalize=False, n_jobs=-1 ⇨ all CPUs are used
lrm.fit(X_train, y_train)
print(lrm.intercept_ , lrm.coef_ )
# 예측값
forecast = lrm.predict(X_test)
print(forecast)
# MSE
mean_squared_error(y_test,forecast)

## LASSO, Ridge 
lasso = Lasso(alpha=0.1); ridge = Ridge(alpha=0.1)  # alpha=0: OLS
lasso.fit(X_train, y_train); print(lasso.intercept_ , lasso.coef_ )
forecast = lasso.predict(X_test[0:10,]); print(forecast)

## training-validation procedure(반복 with train-test-split)
result = np.zeros((10,5)); a = [0.001, 0.002, 0.003, 0.004, 0.005]
for step in range(10):
   X0, X1, y0, y1 = train_test_split(X, y, test_size=0.3)
   for choice in range(len(a)):
      lasso = Lasso(alpha=a[choice], normalize=True)
         # sklearn.preprocessing.StandardScaler
      lasso.fit(X0, y0); forecast = lasso.predict(X1)
      result[step,choice] = mean_squared_error(y1,forecast)
print(result)
