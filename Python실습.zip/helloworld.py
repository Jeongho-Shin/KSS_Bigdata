print("Good morning, everyone!")

myname="Kyunga Kim"
print(myname.split())

import random
print(random.randint(0,10))