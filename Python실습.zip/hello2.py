
# coding: utf-8

# In[1]:


print("hello, world!")

